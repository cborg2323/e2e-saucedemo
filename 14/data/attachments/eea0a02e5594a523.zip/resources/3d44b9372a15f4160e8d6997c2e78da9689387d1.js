import{X as t}from"./2c1ab0fe.BqEHHmaW.js";const o=t(!1),e="p97qJ",i={RedirectionNotice:e};export{o as O,i as s};
