import{X as o}from"./2c1ab0fe.GMbxnz74.js";const e=o(!1),s={RedirectionNotice:"p97qJ"};export{e as O,s};
